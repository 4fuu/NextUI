#!/bin/sh
exec ./nextui.elf
